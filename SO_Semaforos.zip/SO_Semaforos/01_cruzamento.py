import threading
import time
import random

# Apenas um carro pode ocupar o cruzamento por vez.
cruzamento = threading.Semaphore(1)
sentido = "livre"
mutex_sentido = threading.Lock()

def carro(nome, direcao):
    global sentido
    # Pequena variação para simular a chegada dos veículos.
    time.sleep(random.uniform(0.2, 1.0))

    with cruzamento:
        with mutex_sentido:
            sentido = direcao
            print(f"{nome} está passando no sentido: {sentido}")

        time.sleep(1)  # tempo simulado de travessia

        with mutex_sentido:
            sentido = "livre"
            print(f"{nome} liberou o cruzamento.")

if __name__ == "__main__":
    print("Simulação do cruzamento: somente um carro passa por vez.\\n")
    carros = [
        ("Carro 1", "Norte -> Sul"),
        ("Carro 2", "Oeste -> Leste"),
        ("Carro 3", "Sul -> Norte"),
        ("Carro 4", "Leste -> Oeste"),
    ]

    threads = [
        threading.Thread(target=carro, args=(nome, direcao))
        for nome, direcao in carros
    ]

    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    print("\\nTodos os carros passaram.")
