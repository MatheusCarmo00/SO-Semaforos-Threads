import threading
import time
import random

QUANTIDADE_EQUIPES = 7
CARROS_POR_EQUIPE = 2
VOLTAS = 3

# No máximo cinco carros podem estar na pista simultaneamente.
pista = threading.Semaphore(5)

# Cada equipe possui um semáforo: apenas um carro da equipe por vez.
semaforos_equipes = [
    threading.Semaphore(1) for _ in range(QUANTIDADE_EQUIPES)
]

def piloto(equipe, carro):
    nome = f"Equipe {equipe + 1} - Carro {carro}"

    for volta in range(1, VOLTAS + 1):
        print(f"{nome}: aguardando para entrar na pista (volta {volta}).")

        # Primeiro garante que não há outro carro da mesma equipe na pista.
        with semaforos_equipes[equipe]:
            # Depois aguarda uma das cinco vagas disponíveis na pista.
            with pista:
                tempo_volta = random.uniform(5, 10)
                print(
                    f"{nome}: iniciou a volta {volta}. "
                    f"Carros na pista: vaga ocupada."
                )
                time.sleep(tempo_volta)
                print(
                    f"{nome}: terminou a volta {volta} "
                    f"em {tempo_volta:.2f} segundos."
                )

    print(f"{nome}: completou as {VOLTAS} voltas.")

if __name__ == "__main__":
    threads = []

    for equipe in range(QUANTIDADE_EQUIPES):
        for carro in range(1, CARROS_POR_EQUIPE + 1):
            thread = threading.Thread(
                target=piloto,
                args=(equipe, carro)
            )
            threads.append(thread)

    random.shuffle(threads)

    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    print("\\nTreino de Fórmula 1 finalizado. Todos os pilotos completaram as voltas.")
