import threading
import time
import random

porta = threading.Semaphore(1)

def pessoa(numero):
    velocidade = random.uniform(4, 6)  # metros por segundo
    distancia = 200
    tempo_caminhada = distancia / velocidade

    print(
        f"Pessoa {numero}: começou a caminhar. "
        f"Velocidade: {velocidade:.2f} m/s."
    )
    time.sleep(tempo_caminhada)

    print(f"Pessoa {numero}: chegou à porta e está aguardando.")

    with porta:
        tempo_porta = random.uniform(1, 2)
        print(
            f"Pessoa {numero}: entrou na porta. "
            f"Tempo para abrir e cruzar: {tempo_porta:.2f} s."
        )
        time.sleep(tempo_porta)
        print(f"Pessoa {numero}: atravessou a porta.")

if __name__ == "__main__":
    threads = [
        threading.Thread(target=pessoa, args=(i,))
        for i in range(1, 5)
    ]

    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    print("\\nAs quatro pessoas atravessaram a porta.")
