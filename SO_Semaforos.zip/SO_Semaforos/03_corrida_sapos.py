import threading
import random
import time

QUANTIDADE_SAPOS = 5

def corrida_sapo(numero, tamanho_maximo_pulo, distancia_maxima):
    posicao = 0

    while posicao < distancia_maxima:
        salto = random.randint(1, tamanho_maximo_pulo)
        posicao += salto

        # A posição final não ultrapassa a distância da corrida.
        if posicao > distancia_maxima:
            posicao = distancia_maxima

        print(
            f"Sapo {numero}: salto de {salto} cm | "
            f"percorreu {posicao} cm de {distancia_maxima} cm"
        )
        time.sleep(random.uniform(0.2, 0.7))

    print(f"🏁 Sapo {numero} chegou à posição {posicao} cm!")

if __name__ == "__main__":
    print("=== Corrida de sapos ===")
    tamanho_maximo_pulo = int(input("Tamanho máximo do pulo (de 1 a 5 cm): "))
    while not 1 <= tamanho_maximo_pulo <= 5:
        tamanho_maximo_pulo = int(input("Digite um valor entre 1 e 5: "))

    distancia_maxima = int(input("Distância máxima da corrida (cm): "))
    while distancia_maxima <= 0:
        distancia_maxima = int(input("Digite uma distância maior que zero: "))

    threads = [
        threading.Thread(
            target=corrida_sapo,
            args=(i, tamanho_maximo_pulo, distancia_maxima)
        )
        for i in range(1, QUANTIDADE_SAPOS + 1)
    ]

    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    print("\\nCorrida finalizada!")
